import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class Main {

    @BeforeSuite
    public static void main(String[] args) {

        System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");

    }

    @Test(testName = "Success")
    void testSuccesful() throws InterruptedException {
        WebDriver driver=new ChromeDriver();
        driver.get("https://politrip.com/account/sign-up");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        JavascriptExecutor js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,250)","");

        driver.findElement(By.id("first-name")).sendKeys("Vasiliu");
        driver.findElement(By.id("last-name")).sendKeys("Vladimir");
        driver.findElement(By.id("email")).sendKeys("vasiliu_vladut@yahoo.com");
        driver.findElement(By.id("sign-up-password-input")).sendKeys("Thisismypass1");
        driver.findElement(By.id("sign-up-confirm-password-input")).sendKeys("Thisismypass1");
        driver.findElement(By.id("sign-up-heard-input")).click();
        WebElement element=driver.findElement(By.id("sign-up-heard-input"));
        Select heard=new Select(element);
        element.click();
        heard.selectByValue("fromAFriend");

        WebElement element1=driver.findElement(By.id(" qa_loader-button"));
        element1.click();

        Thread.sleep(1000);

        //driver.findElement(By.className("type-content")).click();       Aici se creeaza contul;

        driver.close();
    }

    @Test(testName = "FailFirstName")
    void testUnsuccessful1() throws InterruptedException {

        WebDriver driver=new ChromeDriver();
        driver.get("https://politrip.com/account/sign-up");
        driver.manage().window().maximize();
        JavascriptExecutor js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,250)","");

        String firstname=driver.findElement(By.id("first-name")).toString();

        driver.findElement(By.id("first-name")).sendKeys("1234%!");
        driver.findElement(By.id("last-name")).sendKeys("Vladimir");
        driver.findElement(By.id("email")).sendKeys("vasiliu_vladut@yahoo.com");
        driver.findElement(By.id("sign-up-password-input")).sendKeys("Thisismypass1");
        driver.findElement(By.id("sign-up-confirm-password-input")).sendKeys("Thisismypass1");
        driver.findElement(By.id("sign-up-heard-input")).click();
        WebElement element=driver.findElement(By.id("sign-up-heard-input"));
        Select heard=new Select(element);
        element.click();
        heard.selectByValue("fromAFriend");

        WebElement element1=driver.findElement(By.id(" qa_loader-button"));
        element1.click();


        Thread.sleep(1000);

        driver.close();

        Assert.assertEquals(firstname,"1234%!");

    }

    @Test(testName = "FailLastName")
    void testUnsuccessful2() throws InterruptedException {

        WebDriver driver=new ChromeDriver();
        driver.get("https://politrip.com/account/sign-up");
        driver.manage().window().maximize();
        JavascriptExecutor js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,250)","");

        String lastname=driver.findElement(By.id("last-name")).toString();

        driver.findElement(By.id("first-name")).sendKeys("Vasiliu");
        driver.findElement(By.id("last-name")).sendKeys("1234%!");
        driver.findElement(By.id("email")).sendKeys("vasiliu_vladut@yahoo.com");
        driver.findElement(By.id("sign-up-password-input")).sendKeys("Thisismypass1");
        driver.findElement(By.id("sign-up-confirm-password-input")).sendKeys("Thisismypass1");
        driver.findElement(By.id("sign-up-heard-input")).click();
        WebElement element=driver.findElement(By.id("sign-up-heard-input"));
        Select heard=new Select(element);
        element.click();
        heard.selectByValue("fromAFriend");

        WebElement element1=driver.findElement(By.id(" qa_loader-button"));
        element1.click();


        Thread.sleep(1000);

        driver.close();

        Assert.assertEquals(lastname,"1234%!");

    }

    @Test(testName = "FailEmail")
    void testUnsuccessful3() throws InterruptedException {

        WebDriver driver=new ChromeDriver();
        driver.get("https://politrip.com/account/sign-up");
        driver.manage().window().maximize();
        JavascriptExecutor js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,250)","");

        String email=driver.findElement(By.id("email")).toString();

        driver.findElement(By.id("first-name")).sendKeys("Vasiliu");
        driver.findElement(By.id("last-name")).sendKeys("Vladimir");
        driver.findElement(By.id("email")).sendKeys("vasiliu_vladut");
        driver.findElement(By.id("sign-up-password-input")).sendKeys("Thisismypass1");
        driver.findElement(By.id("sign-up-confirm-password-input")).sendKeys("Thisismypass1");
        driver.findElement(By.id("sign-up-heard-input")).click();
        WebElement element=driver.findElement(By.id("sign-up-heard-input"));
        Select heard=new Select(element);
        element.click();
        heard.selectByValue("fromAFriend");

        WebElement element1=driver.findElement(By.id(" qa_loader-button"));
        element1.click();


        Thread.sleep(1000);

        driver.close();

        Assert.assertEquals(email,"vasiliu_vladut");

    }

    @Test(testName = "FailPasswordInput")
    void testUnsuccessful4() throws InterruptedException {

        WebDriver driver=new ChromeDriver();
        driver.get("https://politrip.com/account/sign-up");
        driver.manage().window().maximize();
        JavascriptExecutor js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,250)","");

        String password=driver.findElement(By.id("sign-up-password-input")).toString();

        driver.findElement(By.id("first-name")).sendKeys("Vasiliu");
        driver.findElement(By.id("last-name")).sendKeys("Vladimir");
        driver.findElement(By.id("email")).sendKeys("vasiliu_vladut@yahoo.com");
        driver.findElement(By.id("sign-up-password-input")).sendKeys("thisismypass");
        driver.findElement(By.id("sign-up-confirm-password-input")).sendKeys("thisismypass1");
        driver.findElement(By.id("sign-up-heard-input")).click();
        WebElement element=driver.findElement(By.id("sign-up-heard-input"));
        Select heard=new Select(element);
        element.click();
        heard.selectByValue("fromAFriend");

        WebElement element1=driver.findElement(By.id(" qa_loader-button"));
        element1.click();


        Thread.sleep(1000);

        driver.close();

        Assert.assertEquals(password,"thisismypass");

    }

    @Test(testName = "FailPasswordInputConfirm")
    void testUnsuccessful5() throws InterruptedException {

        WebDriver driver=new ChromeDriver();
        driver.get("https://politrip.com/account/sign-up");
        driver.manage().window().maximize();
        JavascriptExecutor js=(JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,250)","");

        String passwordConfirm=driver.findElement(By.id("sign-up-confirm-password-input")).toString();

        driver.findElement(By.id("first-name")).sendKeys("Vasiliu");
        driver.findElement(By.id("last-name")).sendKeys("Vladimir");
        driver.findElement(By.id("email")).sendKeys("vasiliu_vladut@yahoo.com");
        driver.findElement(By.id("sign-up-password-input")).sendKeys("Thisismypass1");
        driver.findElement(By.id("sign-up-confirm-password-input")).sendKeys("thisismypass1");
        driver.findElement(By.id("sign-up-heard-input")).click();
        WebElement element=driver.findElement(By.id("sign-up-heard-input"));
        Select heard=new Select(element);
        element.click();
        heard.selectByValue("fromAFriend");

        WebElement element1=driver.findElement(By.id(" qa_loader-button"));
        element1.click();


        Thread.sleep(1000);

        driver.close();

        Assert.assertEquals(passwordConfirm,"thisismypass1");

    }




}
